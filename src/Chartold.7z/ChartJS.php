<?php

namespace VicHaunter\ChartJS;



abstract class ChartJS extends ChartJSModel {
    

}
