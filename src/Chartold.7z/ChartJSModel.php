<?php

namespace VicHaunter\ChartJS;

class ChartJSModel {
    
    const CHARTJS_VERSION = '2.7.1';
    
    private $version = null;
    private $htmlMode;
    
    //chart config
    protected $type;
    
    /** @var $options ChartOptions */
    protected $options;
    /** @var $data BarChartDataFactory */
    protected $data;
    
    
    private $chartID;
    private $scheme;
    
    public function __construct($scheme = null, $chartID = null) { //scheme should be only set on start to mantain data integrity
        if($scheme){
            $this->scheme = $scheme;
        }
        $this->chartID = $chartID ? $chartID : $this->getUniqueID();
        
        $this->options = new ChartOptions();
        $this->data = new BarChartDataFactory();
    }
    
    private function getUniqueID() {
        $id = microtime();
        usleep(1);
        $id .= microtime();
        //TODO: find optimal way to retrieve uniq id
        return preg_replace("/[^0-9]/", "", $id);
    }
    
    public function getID(){
        return $this->chartID;
    }
    
    public function setVersion( $version ) {
        $this->version = $version;
    }
    
    public function htmlMode($set = false){
        $this->htmlMode = $set;
    }
    
    public function getJsFileUrl( $custom = null, $loadBundle = true, $html = false ) {
        $url = null;
        if ($custom) {
            $url = $custom;
        }
        $ver = $this->version ? $this->version : self::CHARTJS_VERSION;
        if (!$url && $loadBundle == true) {
            $url = "https://cdn.jsdelivr.net/combine/npm/chart.js@{$ver}/dist/Chart.min.js,npm/chart.js@{$ver}/dist/Chart.bundle.min.js";
        }
        if (!$url) {
            $url = "https://cdn.jsdelivr.net/npm/chart.js@{$ver}/dist/Chart.min.js";
        }
        if ($html) {
            $result = '<script src="'.$url.'"></script>';
        } else {
            $result = $url;
        }
        
        return $result;
    }
    
    public function getHtmlCanvas(){
        return "<canvas id=\"{$this->getID()}\"></canvas>";
    }
    
    public function getData(){
        return $this->data;
    }
    
    public function getDatasets(){
        return $this->datasets;
    }
    public function getCode(){
        $code = [];
        
        $code['type'] = $this->type;
        $code['data'] = $this->data;
        $code['options'] = $this->options;
        
        return json_encode($code);
    }
    
    /**
     * Return full html script with correct format
     *
     * Can be set if needs or not script tags
     *
     * @return string
     */
    public function getHtmlScript($tags = true){
        $script = "";
        if($tags){
            $script .= "<script>";
        }
    
        
        $script .= 'new Chart(document.getElementById("'.$this->getID().'"), '.$this->getCode().');';
        
    
        if($tags){
            $script .= "</script>";
        }
        return $script;
    }
    
    public function addOption( $name, $values){
        $setOption = 'set'.ucfirst($name);
        if(method_exists($this->options, $setOption)) {
            $this->options->$setOption($values);
        }else{
            throw new \ChartJSOptionsException("Option {$name} not exists");
        }
    }
    
    
//    public function setDataLabels(array $labels){
//        $this->data['labels'] = $labels;
//    }
    
    protected function mapColors(array $data,array $colors){
        $previousColor = $colors[0];
        return array_map(function($data,$color) use (&$previousColor) {
            if($color){ $previousColor = $color; }
            return $previousColor;
        }, $data, $colors);
    }
    
}
